import React from 'react'

export function NotFound() {
    

    return (
       <div id="container">
         <h1>
            Page Not Found
        </h1>
       </div>
    )
}
