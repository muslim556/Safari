import React from "react";

export function Account() {
  return <></>;
}
